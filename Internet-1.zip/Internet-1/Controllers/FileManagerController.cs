﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Net;
using Internet_1.Models;
using Internet_1.Repositories;
using Internet_1.ViewModels;

public class FileManagerController : Controller
{
    private readonly ApplicationDbContext _context;
    private readonly string rootPath = @"C:\Your\Root\Directory"; // Root pathi burada belirtiyoruz

    // Yapıcı metod: ApplicationDbContext enjekte ediliyor
    public FileManagerController(ApplicationDbContext context)
    {
        _context = context ?? throw new ArgumentNullException(nameof(context));
    }

    // Index metodu: Dosya veya klasörleri listelemek için kullanılır
    public async Task<IActionResult> Index(string folderPath = "")
    {
        var currentPath = string.IsNullOrEmpty(folderPath) ? rootPath : Path.Combine(rootPath, folderPath);
        var fileManagerViewModels = await _context.FileManagerViewModel
            .Where(f => f.Path.StartsWith(currentPath))
            .ToListAsync();

        ViewBag.CurrentPath = folderPath;
        return View(fileManagerViewModels); // Modeli doğru şekilde gönderiyoruz
    }


    // UploadFile metodu: Dosya yüklemek için kullanılır
    [HttpPost]
    public async Task<IActionResult> UploadFile(string folderPath, IFormFile file)
    {
        if (file == null || file.Length == 0)
        {
            TempData["UploadMessage"] = "No file selected.";
            return RedirectToAction("Index", new { folderPath });
        }

        var targetFolder = Path.Combine(rootPath, folderPath ?? "").TrimEnd(Path.DirectorySeparatorChar);

        if (!targetFolder.StartsWith(rootPath, StringComparison.OrdinalIgnoreCase))
        {
            TempData["UploadMessage"] = "Invalid folder path.";
            return RedirectToAction("Index", new { folderPath });
        }

        var filePath = Path.Combine(targetFolder, file.FileName);

        var fileManagerViewModels = new FileManagerViewModel
        {
            Name = file.FileName ?? throw new ArgumentNullException("File name cannot be null."),
            Path = filePath ?? throw new ArgumentNullException("File path cannot be null."),
            Size = file.Length,
            ModifiedDate = DateTime.Now,
            Type = "File", // Alternatif olarak farklı validasyonlar da eklenebilir.
            UserId = "SomeUserId" // UserId varsa kontrol et, yoksa ekle.
        };


        try
        {
            _context.FileManagerViewModel.Add(fileManagerViewModels);
            await _context.SaveChangesAsync();
            TempData["UploadMessage"] = "File uploaded successfully.";
        }
        catch (DbUpdateException ex)
        {
            var innerException = ex.InnerException?.Message ?? ex.Message;
            TempData["UploadMessage"] = $"Error occurred: {innerException}";
        }


        return RedirectToAction("Index", new { folderPath });
    }


    // Delete metodu: Dosya veya klasör silmek için kullanılır
    public async Task<ActionResult> Delete(string path, string type)
    {
        if (string.IsNullOrEmpty(path) || string.IsNullOrEmpty(type))
        {
            return BadRequest("Path or type cannot be empty.");
        }

        var decodedPath = WebUtility.UrlDecode(path);
        var fullPath = Path.Combine(rootPath, decodedPath);

        if (!fullPath.StartsWith(rootPath, StringComparison.OrdinalIgnoreCase))
        {
            return Forbid("Access to the specified path is not allowed.");
        }

        try
        {
            if (type == "Folder" && Directory.Exists(fullPath))
            {
                Directory.Delete(fullPath, true);
            }
            else if (type == "File" && System.IO.File.Exists(fullPath))
            {
                System.IO.File.Delete(fullPath);
            }
            else
            {
                return NotFound($"{type} not found.");
            }

            var fileManagerViewModels = await _context.FileManagerViewModel.FirstOrDefaultAsync(f => f.Path == fullPath);
            if (fileManagerViewModels != null)
            {
                _context.FileManagerViewModel.Remove(fileManagerViewModels);
                await _context.SaveChangesAsync();
            }

            var parentFolder = Path.GetDirectoryName(decodedPath);
            var relativePath = parentFolder?.Replace(rootPath, "").TrimStart('\\') ?? "";
            return RedirectToAction("Index", new { folderPath = relativePath });
        }
        catch (Exception ex)
        {
            return BadRequest($"An error occurred while deleting: {ex.Message}");
        }
    }

    // Download metodu: Dosya indirmek için kullanılır
    public async Task<ActionResult> Download(string filePath)
    {
        if (string.IsNullOrEmpty(filePath))
        {
            return BadRequest("File path cannot be empty.");
        }

        try
        {
            var decodedFilePath = WebUtility.UrlDecode(filePath);
            var fullPath = Path.Combine(rootPath, decodedFilePath.TrimStart(Path.DirectorySeparatorChar));
            fullPath = Path.GetFullPath(fullPath);

            if (!fullPath.StartsWith(rootPath, StringComparison.OrdinalIgnoreCase))
            {
                return Forbid("Access to the specified file is not allowed.");
            }

            if (!System.IO.File.Exists(fullPath))
            {
                return NotFound("The specified file does not exist.");
            }

            var fileBytes = await System.IO.File.ReadAllBytesAsync(fullPath);
            var fileName = Path.GetFileName(fullPath);

            return File(fileBytes, "application/octet-stream", fileName);
        }
        catch (Exception ex)
        {
            return BadRequest($"An error occurred while processing the file: {ex.Message}");
        }
    }

    [HttpPost]
    public async Task<IActionResult> CreateFolder(string folderName, string folderPath = "")
    {
        if (string.IsNullOrEmpty(folderName))
        {
            TempData["ErrorMessage"] = "Dosya adı boş olamaz.";
            return RedirectToAction("Index", new { folderPath });
        }

        var targetPath = Path.Combine(rootPath, folderPath, folderName.Trim());

        if (Directory.Exists(targetPath))
        {
            TempData["ErrorMessage"] = "Bu isimde bir klasör zaten mevcut.";
            return RedirectToAction("Index", new { folderPath });
        }

        try
        {
            // Klasör oluşturuluyor
            Directory.CreateDirectory(targetPath);

            // Yeni klasör modelini oluşturuyoruz
            var newFolder = new FileManagerViewModel
            {
                Name = folderName,
                Path = targetPath,
                Type = "Folder", // Type'ı "Folder" olarak belirliyoruz
                ModifiedDate = DateTime.Now,
                Size = 0 // Klasör olduğu için boyut 0
            };

            // Veritabanına ekliyoruz
            _context.FileManagerViewModel.Add(newFolder);
            await _context.SaveChangesAsync(); // Değişiklikleri kaydediyoruz

            TempData["SuccessMessage"] = "Klasör başarıyla oluşturuldu.";
        }
        catch (Exception ex)
        {
            TempData["ErrorMessage"] = $"Klasör oluşturulurken hata oluştu: {ex.Message}";
        }

        return RedirectToAction("Index", new { folderPath });
    }



}