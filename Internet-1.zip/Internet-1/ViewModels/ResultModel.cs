﻿namespace Internet_1.ViewModels
{
    public class ResultModel
    {
        public bool Status { get; set; }
        public string Message { get; set; }
    }
}
