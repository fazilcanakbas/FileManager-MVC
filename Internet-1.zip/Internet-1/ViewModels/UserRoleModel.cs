﻿namespace Internet_1.ViewModels
{
    public class UserRoleModel
    {
        public string UserId { get; set; }
        public string RoleId { get; set; }
        public string RoleName { get; set; }
        public bool IsInRole { get; set; }
    }
}
