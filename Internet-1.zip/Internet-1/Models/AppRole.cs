﻿using Microsoft.AspNetCore.Identity;

namespace Internet_1.Models
{
    public class AppRole : IdentityRole
    {
    }
}
