﻿using Internet_1.Models;

public class ProductRepository
{
    private readonly ApplicationDbContext _context;

    public ProductRepository(ApplicationDbContext context)
    {
        _context = context;
    }

    public IEnumerable<Product> GetAllProducts()
    {
        return _context.Products.ToList();
    }

    internal async Task<IEnumerable<object>> GetAllAsync()
    {
        throw new NotImplementedException();
    }
}
